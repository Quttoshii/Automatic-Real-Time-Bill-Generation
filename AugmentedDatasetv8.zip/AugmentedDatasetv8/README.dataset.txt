# School essentials  > 2024-05-07 2:47am
https://universe.roboflow.com/eman-adtrt/school-essentials-zawq9

Provided by a Roboflow user
License: CC BY 4.0

